package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// FUTIVEXA AI Brand Palette: Create • Edit • Grow
val FutivexaViolet = Color(0xFF6366F1)
val FutivexaVioletDark = Color(0xFF4F46E5)
val FutivexaVioletLight = Color(0xFF818CF8)

val FutivexaCyan = Color(0xFF06B6D4)
val FutivexaCyanLight = Color(0xFF22D3EE)

val FutivexaEmerald = Color(0xFF10B981)
val FutivexaRose = Color(0xFFF43F5E)
val FutivexaAmber = Color(0xFFF59E0B)

// Dark Theme Surfaces
val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF131B2E)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkOutline = Color(0xFF334155)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)

// Light Theme Surfaces
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEEF2F6)
val LightOutline = Color(0xFFCBD5E1)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF64748B)

// Gradients & Accents
val AccentGold = Color(0xFFFBBF24)
val AccentPurple = Color(0xFFA855F7)
