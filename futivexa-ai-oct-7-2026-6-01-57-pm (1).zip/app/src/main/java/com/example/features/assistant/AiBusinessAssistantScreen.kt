package com.example.features.assistant

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.ads.AdBannerView
import com.example.core.network.AiResult
import com.example.core.network.GeminiService
import com.example.core.storage.CreditManager
import com.example.core.storage.ProjectEntity
import com.example.core.storage.ProjectRepository
import com.example.core.utils.ImageExportHelper
import com.example.ui.theme.AccentGold
import com.example.ui.theme.FutivexaCyan
import com.example.ui.theme.FutivexaEmerald
import com.example.ui.theme.FutivexaViolet
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiBusinessAssistantScreen(
    geminiService: GeminiService,
    creditManager: CreditManager,
    projectRepository: ProjectRepository,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val isPremium by creditManager.isPremium.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Calculators, 1: AI Advisor

    // Calculator 1: Profit & Margin
    var costPriceStr by remember { mutableStateOf("500") }
    var sellPriceStr by remember { mutableStateOf("700") }

    val costVal = costPriceStr.toDoubleOrNull() ?: 0.0
    val sellVal = sellPriceStr.toDoubleOrNull() ?: 0.0
    val profit = sellVal - costVal
    val profitMargin = if (sellVal > 0) (profit / sellVal) * 100 else 0.0
    val markup = if (costVal > 0) (profit / costVal) * 100 else 0.0

    // Calculator 2: Discount & Sale
    var originalPriceStr by remember { mutableStateOf("2500") }
    var discountPercentStr by remember { mutableStateOf("25") }

    val origVal = originalPriceStr.toDoubleOrNull() ?: 0.0
    val discVal = discountPercentStr.toDoubleOrNull() ?: 0.0
    val savings = origVal * (discVal / 100.0)
    val finalSalePrice = origVal - savings

    // Calculator 3: Break-Even
    var fixedCostStr by remember { mutableStateOf("50000") }
    var unitCostStr by remember { mutableStateOf("300") }
    var unitSellStr by remember { mutableStateOf("500") }

    val fixedCost = fixedCostStr.toDoubleOrNull() ?: 0.0
    val unitCost = unitCostStr.toDoubleOrNull() ?: 0.0
    val unitSell = unitSellStr.toDoubleOrNull() ?: 0.0
    val unitProfit = unitSell - unitCost
    val breakEvenUnits = if (unitProfit > 0) (fixedCost / unitProfit).toInt() else 0

    // AI Advisor state
    val advisorTools = remember {
        listOf(
            "Marketing Ideas",
            "Product Description",
            "Customer Reply",
            "WhatsApp Promotion",
            "Business Names",
            "Special Offers"
        )
    }
    var selectedAdvisorTool by remember { mutableStateOf(advisorTools[0]) }
    var businessNiche by remember { mutableStateOf("Handcrafted Leather Bags & Wallets") }
    var advisorQueryDetails by remember { mutableStateOf("How to increase sales for young professionals and run a weekend deal?") }
    var generatedAdvice by remember { mutableStateOf("") }
    var isGenerating by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successToast by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("AI Business Assistant", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(
                            text = "Calculators & Smart Growth Tools",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Tab Selector
            TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Smart Calculators", fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.Calculate, contentDescription = null) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("AI Growth Advisor", fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.Lightbulb, contentDescription = null) }
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (selectedTab == 0) {
                    // CALCULATORS TAB
                    // 1. Profit & Margin Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AttachMoney, contentDescription = null, tint = FutivexaEmerald)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Profit & Margin Calculator", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = costPriceStr,
                                    onValueChange = { costPriceStr = it },
                                    label = { Text("Cost Price") },
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = sellPriceStr,
                                    onValueChange = { sellPriceStr = it },
                                    label = { Text("Selling Price") },
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            // Result Pill
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceAround
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Net Profit", style = MaterialTheme.typography.labelSmall)
                                        Text("Rs. ${"%.0f".format(profit)}", fontWeight = FontWeight.ExtraBold, color = FutivexaEmerald, fontSize = 18.sp)
                                    }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Profit Margin", style = MaterialTheme.typography.labelSmall)
                                        Text("${"%.1f".format(profitMargin)}%", fontWeight = FontWeight.Bold, color = FutivexaViolet)
                                    }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Markup", style = MaterialTheme.typography.labelSmall)
                                        Text("${"%.1f".format(markup)}%", fontWeight = FontWeight.Bold, color = AccentGold)
                                    }
                                }
                            }
                        }
                    }

                    // 2. Discount & Sale Price Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.LocalOffer, contentDescription = null, tint = AccentGold)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Discount & Sale Price Calculator", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = originalPriceStr,
                                    onValueChange = { originalPriceStr = it },
                                    label = { Text("Original Price") },
                                    modifier = Modifier.weight(1.2f)
                                )
                                OutlinedTextField(
                                    value = discountPercentStr,
                                    onValueChange = { discountPercentStr = it },
                                    label = { Text("Discount %") },
                                    modifier = Modifier.weight(0.8f)
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceAround
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Final Sale Price", style = MaterialTheme.typography.labelSmall)
                                        Text("Rs. ${"%.0f".format(finalSalePrice)}", fontWeight = FontWeight.ExtraBold, color = FutivexaCyan, fontSize = 18.sp)
                                    }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Customer Saves", style = MaterialTheme.typography.labelSmall)
                                        Text("Rs. ${"%.0f".format(savings)}", fontWeight = FontWeight.Bold, color = FutivexaEmerald)
                                    }
                                }
                            }
                        }
                    }

                    // 3. Break-Even Calculator
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.TrendingUp, contentDescription = null, tint = FutivexaViolet)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Break-Even Units Calculator", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }

                            OutlinedTextField(
                                value = fixedCostStr,
                                onValueChange = { fixedCostStr = it },
                                label = { Text("Monthly Fixed Costs (Rent, Electricity, Salary)") },
                                modifier = Modifier.fillMaxWidth()
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = unitCostStr,
                                    onValueChange = { unitCostStr = it },
                                    label = { Text("Cost Per Unit") },
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = unitSellStr,
                                    onValueChange = { unitSellStr = it },
                                    label = { Text("Sale Per Unit") },
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceAround,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Units Needed to Break-Even", style = MaterialTheme.typography.labelSmall)
                                        Text(
                                            text = if (unitProfit <= 0) "Price too low" else "$breakEvenUnits Units / month",
                                            fontWeight = FontWeight.ExtraBold,
                                            color = if (unitProfit <= 0) MaterialTheme.colorScheme.error else FutivexaViolet,
                                            fontSize = 18.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // AI ADVISOR TAB
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "Select Assistant Tool",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                advisorTools.take(3).forEach { tool ->
                                    FilterChip(
                                        selected = selectedAdvisorTool == tool,
                                        onClick = { selectedAdvisorTool = tool },
                                        label = { Text(tool) }
                                    )
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                advisorTools.drop(3).forEach { tool ->
                                    FilterChip(
                                        selected = selectedAdvisorTool == tool,
                                        onClick = { selectedAdvisorTool = tool },
                                        label = { Text(tool) }
                                    )
                                }
                            }

                            OutlinedTextField(
                                value = businessNiche,
                                onValueChange = { businessNiche = it },
                                label = { Text("Business Niche / Category") },
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = advisorQueryDetails,
                                onValueChange = { advisorQueryDetails = it },
                                label = { Text("Specific Question or Context") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 2
                            )

                            Button(
                                onClick = {
                                    if (!creditManager.hasCredits()) {
                                        errorMessage = "Daily AI credits finished. Watch an ad to top-up!"
                                        return@Button
                                    }
                                    isGenerating = true
                                    errorMessage = null
                                    coroutineScope.launch {
                                        val prompt = "Provide expert small business advice for '$selectedAdvisorTool'. Business: $businessNiche. Context: $advisorQueryDetails. Keep it structured with action steps, clear examples, and high-impact takeaways."
                                        val result = geminiService.generateContent(
                                            prompt = prompt,
                                            systemInstruction = "You are FUTIVEXA AI's Small Business & Growth Consultant. Give practical, high-conversion, real-world advice."
                                        )
                                        isGenerating = false
                                        creditManager.consumeCredit()

                                        when (result) {
                                            is AiResult.Success -> {
                                                generatedAdvice = result.data
                                                successToast = "Strategy generated!"
                                            }
                                            is AiResult.Error -> {
                                                errorMessage = result.message
                                            }
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("generate_assistant_advice_btn"),
                                colors = ButtonDefaults.buttonColors(containerColor = FutivexaViolet)
                            ) {
                                if (isGenerating) {
                                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Consulting AI Assistant...")
                                } else {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Generate $selectedAdvisorTool")
                                }
                            }

                            if (generatedAdvice.isNotBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Text(
                                            text = generatedAdvice,
                                            style = MaterialTheme.typography.bodyMedium,
                                            lineHeight = 22.sp
                                        )

                                        Spacer(modifier = Modifier.height(12.dp))

                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            FilledTonalButton(
                                                onClick = {
                                                    ImageExportHelper.copyToClipboard(context, generatedAdvice)
                                                }
                                            ) {
                                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Copy")
                                            }

                                            FilledTonalButton(
                                                onClick = {
                                                    coroutineScope.launch {
                                                        val entity = ProjectEntity(
                                                            title = "$selectedAdvisorTool: $businessNiche",
                                                            type = "ASSISTANT_NOTE",
                                                            subtitle = "AI Strategy Note",
                                                            contentData = generatedAdvice
                                                        )
                                                        projectRepository.saveProject(entity)
                                                        successToast = "Saved to project library!"
                                                    }
                                                }
                                            ) {
                                                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Save Note")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Error / Success
                errorMessage?.let { err ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                        Text(text = err, color = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.padding(12.dp))
                    }
                }

                successToast?.let { msg ->
                    Card(colors = CardDefaults.cardColors(containerColor = FutivexaEmerald.copy(alpha = 0.2f))) {
                        Text(text = msg, color = FutivexaEmerald, fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp))
                    }
                }

                AdBannerView(isPremium = isPremium)
            }
        }
    }
}
