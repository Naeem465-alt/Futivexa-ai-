package com.example.features.urdu

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.core.ads.AdBannerView
import com.example.core.network.AiResult
import com.example.core.network.GeminiService
import com.example.core.storage.CreditManager
import com.example.core.storage.ProjectEntity
import com.example.core.storage.ProjectRepository
import com.example.core.utils.ImageExportHelper
import com.example.ui.theme.AccentGold
import com.example.ui.theme.FutivexaEmerald
import com.example.ui.theme.FutivexaViolet
import kotlinx.coroutines.launch

data class UrduCategory(val id: String, val urduName: String, val engName: String, val sampleText: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UrduContentCreatorScreen(
    geminiService: GeminiService,
    creditManager: CreditManager,
    projectRepository: ProjectRepository,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val isPremium by creditManager.isPremium.collectAsState()

    val categories = remember {
        listOf(
            UrduCategory(
                "motivational",
                "حوصلہ افزائی",
                "Motivational",
                "منزلیں اُنہی کو ملتی ہیں جن کے خوابوں میں جان ہوتی ہے۔ پروں سے کچھ نہیں ہوتا، حوصلوں سے اڑان ہوتی ہے۔"
            ),
            UrduCategory(
                "life_advice",
                "زندگی کی نصیحت",
                "Life Advice",
                "زندگی میں ہمیشہ خاموشی کے ساتھ محنت کرو، تاکہ تمہاری کامیابی شور مچا دے۔"
            ),
            UrduCategory(
                "poetry",
                "شاعری",
                "Poetry",
                "ہزاروں خواہشیں ایسی کہ ہر خواہش پہ دم نکلے\nبہت نکلے مرے ارمان لیکن پھر بھی کم نکلے"
            ),
            UrduCategory(
                "quotes",
                "اقوالِ زریں",
                "Quotes",
                "علم انسان کو روشنی دیتا ہے، اور عمل اس روشنی کو دوسروں تک پہنچاتا ہے۔"
            ),
            UrduCategory(
                "knowledge",
                "معلومات و شعور",
                "Knowledge",
                "دنیا کا سب سے بڑا خزانہ اچھی سوچ اور مسلسل سیکھنے کا جذبہ ہے۔"
            ),
            UrduCategory(
                "business",
                "کاروباری سوچ",
                "Business",
                "کامیاب تاجر وہ ہے جو منافع سے زیادہ اپنے گاہک کے اعتماد کو اہمیت دیتا ہے۔"
            ),
            UrduCategory(
                "islamic",
                "اسلامی و روحانی",
                "Islamic & Spiritual",
                "صبر کا دامن کبھی مت چھوڑو، کیونکہ رب کائنات صبر کرنے والوں کے ساتھ ہے۔"
            ),
            UrduCategory(
                "relationships",
                "رشتے اور اخلاق",
                "Relationships",
                "رشتے احساس سے بنتے ہیں، الفاظ سے نہیں۔ زبان کی نرمی رشتوں کی عمر بڑھا دیتی ہے۔"
            ),
            UrduCategory(
                "success",
                "کامیابی",
                "Success",
                "ناکامی صرف ایک نیا آغاز ہے، اس بار مزید دانشمندی کے ساتھ کوشش کریں۔"
            ),
            UrduCategory(
                "daily",
                "روزمرہ سوچ",
                "Daily Thoughts",
                "ہر صبح ایک نئی امید کا پیغام لے کر آتی ہے، مسکرائیں اور مثبت سوچیں۔"
            )
        )
    }

    var selectedCategory by remember { mutableStateOf(categories[0]) }
    var urduText by remember { mutableStateOf(selectedCategory.sampleText) }
    var englishTranslation by remember { mutableStateOf("Destinations are reached by those whose dreams have conviction. Wings alone do nothing, flight belongs to courage.") }
    var authorSign by remember { mutableStateOf("FUTIVEXA AI • اردو ادب") }

    // Poster styling
    var selectedRatio by remember { mutableStateOf("1:1") } // 1:1, 9:16
    var selectedThemeIdx by remember { mutableIntStateOf(0) }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var isAiGenerating by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successToast by remember { mutableStateOf<String?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) selectedImageUri = uri
    }

    val themes = remember {
        listOf(
            Brush.verticalGradient(listOf(Color(0xFF064E3B), Color(0xFF0F172A))), // Emerald Gold
            Brush.verticalGradient(listOf(Color(0xFF1E1B4B), Color(0xFF0B0F19))), // Royal Midnight
            Brush.verticalGradient(listOf(Color(0xFF831843), Color(0xFF1E293B))), // Sunset Crimson
            Brush.verticalGradient(listOf(Color(0xFF0F172A), Color(0xFF1E293B)))  // Classic Slate
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("اردو کنٹینٹ کرئیٹر", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(
                            text = "Urdu Content & RTL Poetry Studio",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Category Chips Row (RTL friendly)
            Text(
                text = "کیٹیگری منتخب کریں (Choose Category)",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold
            )

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories) { cat ->
                    FilterChip(
                        selected = selectedCategory.id == cat.id,
                        onClick = {
                            selectedCategory = cat
                            urduText = cat.sampleText
                        },
                        label = { Text(cat.urduName, fontWeight = FontWeight.Bold) }
                    )
                }
            }

            // Live Urdu Poster Preview Canvas (RTL)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("urdu_poster_canvas"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "LIVE URDU POSTER ($selectedRatio)",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Poster Canvas Frame
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(if (selectedRatio == "9:16") 0.65f else 0.88f)
                            .aspectRatio(if (selectedRatio == "9:16") 9f / 16f else 1f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(themes[selectedThemeIdx])
                            .border(1.5.dp, AccentGold.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                            .padding(16.dp)
                    ) {
                        // RTL Content Layout
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.SpaceBetween,
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                // Header Decorative Mark
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "﷽",
                                        color = AccentGold,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = Color.Black.copy(alpha = 0.4f)
                                    ) {
                                        Text(
                                            text = selectedCategory.urduName,
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                // Center Poetry/Quote in Urdu
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = urduText,
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        textAlign = TextAlign.Center,
                                        lineHeight = 32.sp,
                                        modifier = Modifier.padding(horizontal = 8.dp)
                                    )

                                    if (englishTranslation.isNotBlank() && selectedRatio == "9:16") {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                            Text(
                                                text = englishTranslation,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Color.White.copy(alpha = 0.75f),
                                                textAlign = TextAlign.Center,
                                                lineHeight = 16.sp
                                            )
                                        }
                                    }
                                }

                                // Footer Signature
                                Text(
                                    text = authorSign,
                                    color = AccentGold,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Controls Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf("1:1", "9:16").forEach { ratio ->
                            FilterChip(
                                selected = selectedRatio == ratio,
                                onClick = { selectedRatio = ratio },
                                label = { Text(if (ratio == "1:1") "Square Post" else "Status (9:16)") }
                            )
                        }

                        OutlinedButton(
                            onClick = { selectedThemeIdx = (selectedThemeIdx + 1) % themes.size }
                        ) {
                            Icon(Icons.Default.Palette, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Theme")
                        }
                    }
                }
            }

            // AI Urdu Generation Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "AI اردو تحریر و شاعری جنریٹر",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Button(
                        onClick = {
                            if (!creditManager.hasCredits()) {
                                errorMessage = "روزانہ اے آئی لمٹ ختم ہو گئی ہے۔ اشتہار دیکھ کر نئے کریڈٹ حاصل کریں۔"
                                return@Button
                            }
                            isAiGenerating = true
                            errorMessage = null
                            coroutineScope.launch {
                                val prompt = "اردو میں کیٹیگری '${selectedCategory.urduName}' کے بارے میں انتہائی خوبصورت اور پرتاثیر تحریر، شعر یا قول تخلیق کریں۔ ساتھ میں مختصر انگریزی ترجمہ بھی دیں۔"
                                val result = geminiService.generateContent(
                                    prompt = prompt,
                                    systemInstruction = "You are a master Urdu literary poet and motivational author. Write authentic, poetic, high-standard Urdu."
                                )

                                isAiGenerating = false
                                creditManager.consumeCredit()

                                when (result) {
                                    is AiResult.Success -> {
                                        val parts = result.data.split("\n\n")
                                        urduText = parts.firstOrNull()?.trim() ?: result.data
                                        if (parts.size > 1) {
                                            englishTranslation = parts[1].trim()
                                        }
                                        successToast = "نئی اردو تحریر کامیابی سے تیار ہو گئی!"
                                    }
                                    is AiResult.Error -> {
                                        errorMessage = result.urduMessage
                                    }
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("ai_generate_urdu_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = FutivexaEmerald)
                    ) {
                        if (isAiGenerating) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("تحریر تخلیق ہو رہی ہے...", color = Color.White)
                        } else {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("نئی اردو تحریر تخلیق کریں", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }

                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        OutlinedTextField(
                            value = urduText,
                            onValueChange = { urduText = it },
                            label = { Text("اردو تحریر (ایڈٹ کریں)") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 3
                        )
                    }

                    OutlinedTextField(
                        value = englishTranslation,
                        onValueChange = { englishTranslation = it },
                        label = { Text("English Translation / Subtitle") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )

                    OutlinedTextField(
                        value = authorSign,
                        onValueChange = { authorSign = it },
                        label = { Text("Author Tag / Signature") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Action Buttons (Copy, Save, Export)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        val full = "$urduText\n\n$englishTranslation\n\n— $authorSign"
                        ImageExportHelper.copyToClipboard(context, full)
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Copy", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                Button(
                    onClick = {
                        coroutineScope.launch {
                            val entity = ProjectEntity(
                                title = urduText.take(30),
                                type = "URDU_POST",
                                subtitle = selectedCategory.urduName,
                                aspectRatio = selectedRatio,
                                contentData = "$urduText\n$englishTranslation",
                                language = "Urdu"
                            )
                            projectRepository.saveProject(entity)
                            successToast = "محفوظ کر لیا گیا! (Saved to Projects)"
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Save", color = MaterialTheme.colorScheme.onPrimaryContainer)
                }

                Button(
                    onClick = {
                        val bitmap = ImageExportHelper.createPosterBitmap(
                            title = urduText.take(40),
                            subtitle = authorSign,
                            price = "",
                            discount = "",
                            businessName = selectedCategory.urduName,
                            phone = "",
                            isUrdu = true
                        )
                        val uri = ImageExportHelper.saveBitmapToCache(context, bitmap, "futivexa_urdu_${System.currentTimeMillis()}.png")
                        if (uri != null) {
                            val shareIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                type = "image/png"
                                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                                putExtra(android.content.Intent.EXTRA_TEXT, "$urduText\n\n$englishTranslation\n— $authorSign")
                                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(android.content.Intent.createChooser(shareIntent, "Share Urdu Post"))
                        }
                    },
                    modifier = Modifier.weight(1.2f),
                    colors = ButtonDefaults.buttonColors(containerColor = FutivexaEmerald)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Share Post", fontWeight = FontWeight.Bold)
                }
            }

            // Error or Success Messages
            errorMessage?.let { err ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Text(text = err, color = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.padding(12.dp))
                }
            }

            successToast?.let { msg ->
                Card(colors = CardDefaults.cardColors(containerColor = FutivexaEmerald.copy(alpha = 0.2f))) {
                    Text(text = msg, color = FutivexaEmerald, fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp))
                }
            }

            AdBannerView(isPremium = isPremium)
        }
    }
}
