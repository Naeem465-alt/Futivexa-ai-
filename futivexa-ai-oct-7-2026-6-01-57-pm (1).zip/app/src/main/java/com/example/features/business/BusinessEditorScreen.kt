package com.example.features.business

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.core.ads.AdBannerView
import com.example.core.network.AiResult
import com.example.core.network.GeminiService
import com.example.core.storage.CreditManager
import com.example.core.storage.ProjectEntity
import com.example.core.storage.ProjectRepository
import com.example.core.utils.ImageExportHelper
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BusinessEditorScreen(
    geminiService: GeminiService,
    creditManager: CreditManager,
    projectRepository: ProjectRepository,
    initialProjectId: Long = 0,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val isPremium by creditManager.isPremium.collectAsState()

    // Form Inputs
    var productName by remember { mutableStateOf("Smart Android Watch Ultra") }
    var price by remember { mutableStateOf("Rs. 4,999") }
    var oldPrice by remember { mutableStateOf("Rs. 7,499") }
    var discount by remember { mutableStateOf("35% OFF") }
    var businessName by remember { mutableStateOf("Apex Tech Store") }
    var phone by remember { mutableStateOf("+92 300 1234567") }
    var location by remember { mutableStateOf("Karachi / Free Nationwide Delivery") }
    var offerDetails by remember { mutableStateOf("Free silicone strap + 1-year warranty included!") }
    var isUrdu by remember { mutableStateOf(false) }

    // Canvas Settings
    var selectedRatio by remember { mutableStateOf("1:1") } // 1:1, 4:5, 9:16, 16:9
    var selectedTemplate by remember { mutableIntStateOf(0) } // 0: Neon Glow, 1: Bold Super Sale, 2: Luxury Minimal
    var selectedBgTheme by remember { mutableIntStateOf(0) } // 0: Indigo Dark, 1: Emerald Teal, 2: Cyber Purple
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }

    // AI Generated Text Fields
    var generatedHeadline by remember { mutableStateOf("SUPER SALE • LIMITED TIME OFFER") }
    var generatedCaption by remember { mutableStateOf("Upgrade your style with top performance and premium durability. Fast shipping right to your doorstep!") }
    var generatedHashtags by remember { mutableStateOf("#SmartWatch #TechSale #ApexTech #OnlineShoppingPK") }
    var isAiGenerating by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successToast by remember { mutableStateOf<String?>(null) }

    // Photo Picker Launcher
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            selectedImageUri = uri
        }
    }

    val ratioAspect = when (selectedRatio) {
        "4:5" -> 4f / 5f
        "9:16" -> 9f / 16f
        "16:9" -> 16f / 9f
        else -> 1f
    }

    val bgBrushes = listOf(
        Brush.verticalGradient(listOf(Color(0xFF0F172A), Color(0xFF1E1B4B))),
        Brush.verticalGradient(listOf(Color(0xFF064E3B), Color(0xFF0F172A))),
        Brush.verticalGradient(listOf(Color(0xFF581C87), Color(0xFF0F172A)))
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Business Editor", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(
                            text = if (isUrdu) "بزنس اشتہار ساز" else "AI Ad & Poster Studio",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // Language Switcher
                    FilterChip(
                        selected = isUrdu,
                        onClick = { isUrdu = !isUrdu },
                        label = { Text(if (isUrdu) "اردو" else "English", fontWeight = FontWeight.Bold) },
                        modifier = Modifier.padding(end = 8.dp)
                    )
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Live Poster Canvas Preview
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("business_poster_canvas"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "LIVE CANVAS PREVIEW ($selectedRatio)",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Simulated Poster Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(if (selectedRatio == "16:9") 1f else if (selectedRatio == "9:16") 0.65f else 0.85f)
                            .aspectRatio(ratioAspect)
                            .clip(RoundedCornerShape(16.dp))
                            .background(bgBrushes[selectedBgTheme])
                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                            .padding(14.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.SpaceBetween,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Header bar
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color.Black.copy(alpha = 0.4f)
                                ) {
                                    Text(
                                        text = businessName.ifBlank { "FUTIVEXA AI" },
                                        color = Color.White,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }

                                if (discount.isNotBlank()) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = FutivexaEmerald
                                    ) {
                                        Text(
                                            text = discount,
                                            color = Color.White,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.ExtraBold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }

                            // Center Image or Icon
                            Box(
                                modifier = Modifier
                                    .size(if (selectedRatio == "16:9") 70.dp else 100.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.White.copy(alpha = 0.08f)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (selectedImageUri != null) {
                                    AsyncImage(
                                        model = selectedImageUri,
                                        contentDescription = "Product Image",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.ShoppingBag,
                                        contentDescription = "Default Product",
                                        tint = FutivexaCyanLight,
                                        modifier = Modifier.size(48.dp)
                                    )
                                }
                            }

                            // Product details & Headline
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = generatedHeadline,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = AccentGold,
                                    fontWeight = FontWeight.ExtraBold,
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = productName.ifBlank { "Premium Product" },
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = price,
                                        color = FutivexaCyanLight,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                    if (oldPrice.isNotBlank()) {
                                        Text(
                                            text = oldPrice,
                                            color = Color.Gray,
                                            style = MaterialTheme.typography.labelSmall,
                                            textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough
                                        )
                                    }
                                }
                            }

                            // Footer CTA & Contact
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color.White.copy(alpha = 0.15f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 4.dp, horizontal = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = if (phone.isNotBlank()) "WhatsApp to Order: $phone" else "Order Now",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (location.isNotBlank()) {
                                        Text(
                                            text = location,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White.copy(alpha = 0.7f),
                                            fontSize = 9.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Aspect Ratio Picker Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf("1:1", "4:5", "9:16", "16:9").forEach { ratio ->
                            FilterChip(
                                selected = selectedRatio == ratio,
                                onClick = { selectedRatio = ratio },
                                label = { Text(ratio) }
                            )
                        }
                    }
                }
            }

            // Quick Canvas Controls (Theme, Image upload)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("upload_product_photo_btn")
                ) {
                    Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (selectedImageUri == null) "Add Photo" else "Change Photo")
                }

                OutlinedButton(
                    onClick = {
                        selectedBgTheme = (selectedBgTheme + 1) % bgBrushes.size
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Palette, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Change Theme")
                }
            }

            // Product Details Inputs Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Product & Store Information",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    OutlinedTextField(
                        value = productName,
                        onValueChange = { productName = it },
                        label = { Text("Product Name") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_product_name")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = price,
                            onValueChange = { price = it },
                            label = { Text("Sale Price") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = oldPrice,
                            onValueChange = { oldPrice = it },
                            label = { Text("Old Price") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = discount,
                            onValueChange = { discount = it },
                            label = { Text("Discount") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = businessName,
                        onValueChange = { businessName = it },
                        label = { Text("Business / Store Name") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = it },
                            label = { Text("WhatsApp Number") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = location,
                            onValueChange = { location = it },
                            label = { Text("Location / Delivery") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = offerDetails,
                        onValueChange = { offerDetails = it },
                        label = { Text("Offer Details / Perks") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 2
                    )

                    // AI Generation Action Button
                    Button(
                        onClick = {
                            if (!creditManager.hasCredits()) {
                                errorMessage = "You have reached your daily AI generations limit. Earn more via rewarded ads!"
                                return@Button
                            }
                            isAiGenerating = true
                            errorMessage = null
                            coroutineScope.launch {
                                val prompt = if (isUrdu) {
                                    "Generate high-converting Urdu marketing advertisement headline, attractive caption, call-to-action and hashtags for product: $productName, Price: $price (Old: $oldPrice), Discount: $discount, Business: $businessName, Offer: $offerDetails."
                                } else {
                                    "Generate an enticing high-converting marketing headline, product caption, call-to-action and hashtags for: $productName, Price: $price (Old: $oldPrice), Discount: $discount, Business: $businessName, Offer: $offerDetails."
                                }

                                val result = geminiService.generateContent(
                                    prompt = prompt,
                                    systemInstruction = "You are an elite marketing copywriter for FUTIVEXA AI. Output clean, punchy advertising copy."
                                )

                                isAiGenerating = false
                                creditManager.consumeCredit()

                                when (result) {
                                    is AiResult.Success -> {
                                        val lines = result.data.split("\n").filter { it.isNotBlank() }
                                        if (lines.isNotEmpty()) {
                                            generatedHeadline = lines.firstOrNull()?.take(40) ?: "EXCLUSIVE SALE"
                                            generatedCaption = lines.drop(1).take(2).joinToString(" ")
                                            val tagLine = lines.find { it.contains("#") }
                                            if (tagLine != null) generatedHashtags = tagLine
                                        }
                                        successToast = "AI ad copy generated successfully!"
                                    }
                                    is AiResult.Error -> {
                                        errorMessage = if (isUrdu) result.urduMessage else result.message
                                    }
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("ai_generate_ad_copy_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = FutivexaViolet)
                    ) {
                        if (isAiGenerating) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Generating with AI...")
                        } else {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("AI Generate Copy & Captions")
                        }
                    }
                }
            }

            // AI Generated Copy Preview & Customizer
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Generated Ad Copy & Social Post",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    OutlinedTextField(
                        value = generatedHeadline,
                        onValueChange = { generatedHeadline = it },
                        label = { Text("Banner Headline") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = generatedCaption,
                        onValueChange = { generatedCaption = it },
                        label = { Text("Social Media Caption") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )

                    OutlinedTextField(
                        value = generatedHashtags,
                        onValueChange = { generatedHashtags = it },
                        label = { Text("Hashtags") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilledTonalButton(
                            onClick = {
                                val fullText = "$generatedHeadline\n\n$productName - $price ($discount)\n$generatedCaption\n\nOrder on WhatsApp: $phone\n\n$generatedHashtags"
                                ImageExportHelper.copyToClipboard(context, fullText)
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Copy Text")
                        }

                        FilledTonalButton(
                            onClick = {
                                val fullText = "$generatedHeadline\n\n$productName - $price ($discount)\n$generatedCaption\n\nOrder on WhatsApp: $phone\n\n$generatedHashtags"
                                ImageExportHelper.shareToWhatsApp(context, fullText)
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("WhatsApp")
                        }
                    }
                }
            }

            // Export & Save Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            val entity = ProjectEntity(
                                title = productName.ifBlank { "Business Ad" },
                                type = "BUSINESS_AD",
                                subtitle = "$price • $discount",
                                aspectRatio = selectedRatio,
                                contentData = "$generatedHeadline | $generatedCaption | $phone",
                                language = if (isUrdu) "Urdu" else "English"
                            )
                            projectRepository.saveProject(entity)
                            successToast = "Project saved to your local library!"
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("save_project_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        Icons.Default.Save,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Save Project", color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        val bitmap = ImageExportHelper.createPosterBitmap(
                            title = productName,
                            subtitle = generatedHeadline,
                            price = price,
                            discount = discount,
                            businessName = businessName,
                            phone = phone,
                            isUrdu = isUrdu
                        )
                        val uri = ImageExportHelper.saveBitmapToCache(context, bitmap, "futivexa_${System.currentTimeMillis()}.png")
                        if (uri != null) {
                            val shareIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                type = "image/png"
                                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                                putExtra(android.content.Intent.EXTRA_TEXT, "$generatedHeadline - $productName ($price)\nWhatsApp: $phone")
                                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(android.content.Intent.createChooser(shareIntent, "Export FUTIVEXA Poster"))
                            successToast = "Poster ready to export & share!"
                        } else {
                            errorMessage = "Export failed. Please check device permissions."
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("export_image_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = FutivexaEmerald),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Export Image", fontWeight = FontWeight.Bold)
                }
            }

            // Error or Success Banner
            errorMessage?.let { err ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = err, color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 13.sp)
                    }
                }
            }

            successToast?.let { msg ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = FutivexaEmerald.copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = FutivexaEmerald)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = msg, color = FutivexaEmerald, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            AdBannerView(isPremium = isPremium)
        }
    }
}
