package com.example.features.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.core.ads.AdBannerView
import com.example.core.ads.RewardedAdDialog
import com.example.core.storage.CreditManager
import com.example.core.storage.ProjectEntity
import com.example.ui.theme.*

data class ModuleCardInfo(
    val id: String,
    val title: String,
    val urduTitle: String,
    val description: String,
    val icon: ImageVector,
    val gradient: List<Color>,
    val badge: String = ""
)

@Composable
fun HomeScreen(
    creditManager: CreditManager,
    recentProjects: List<ProjectEntity>,
    onNavigateToModule: (String) -> Unit,
    onNavigateToProject: (Long) -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val creditsRemaining by creditManager.creditsRemaining.collectAsState()
    val maxCredits by creditManager.maxDailyLimit.collectAsState()
    val isPremium by creditManager.isPremium.collectAsState()
    var showRewardAdDialog by remember { mutableStateOf(false) }

    val modules = remember {
        listOf(
            ModuleCardInfo(
                id = "business_editor",
                title = "Business Editor",
                urduTitle = "بزنس ایڈورٹائزنگ ایڈیٹر",
                description = "Craft high-converting product ads, sales flyers, discount badges & poster designs.",
                icon = Icons.Default.Campaign,
                gradient = listOf(Color(0xFF6366F1), Color(0xFF4F46E5)),
                badge = "POPULAR"
            ),
            ModuleCardInfo(
                id = "whatsapp_creator",
                title = "WhatsApp Creator",
                urduTitle = "واٹس ایپ اسٹیٹس میکر",
                description = "9:16 status cards, product promotions & one-click direct WhatsApp sharing.",
                icon = Icons.Default.Chat,
                gradient = listOf(Color(0xFF06B6D4), Color(0xFF0E7490)),
                badge = "INSTANT"
            ),
            ModuleCardInfo(
                id = "video_maker",
                title = "AI Video Maker",
                urduTitle = "شارٹ ویڈیو میکر",
                description = "Turn product photos into dynamic short videos with transitions and beat tracks.",
                icon = Icons.Default.MovieFilter,
                gradient = listOf(Color(0xFF8B5CF6), Color(0xFF6D28D9)),
                badge = "9:16 SHORTS"
            ),
            ModuleCardInfo(
                id = "urdu_creator",
                title = "Urdu Content Creator",
                urduTitle = "اردو پوسٹ و شاعری",
                description = "Motivational quotes, poetry & daily wisdom in beautiful RTL Nastaliq styling.",
                icon = Icons.Default.Translate,
                gradient = listOf(Color(0xFF10B981), Color(0xFF047857)),
                badge = "URDU RTL"
            ),
            ModuleCardInfo(
                id = "business_assistant",
                title = "AI Business Assistant",
                urduTitle = "سمارٹ بزنس اسسٹنٹ",
                description = "Profit & margin calculators, marketing strategies, captions & reply generator.",
                icon = Icons.Default.Analytics,
                gradient = listOf(Color(0xFFF59E0B), Color(0xFFD97706)),
                badge = "CALCULATOR"
            )
        )
    }

    if (showRewardAdDialog) {
        RewardedAdDialog(
            onDismiss = { showRewardAdDialog = false },
            onRewardEarned = { amount ->
                creditManager.addRewardCredits(amount)
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_screen_lazy_column"),
        contentPadding = PaddingValues(bottom = 100.dp)
    ) {
        // Hero Brand Banner Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .testTag("hero_brand_card"),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Box(modifier = Modifier.fillMaxWidth()) {
                    // Header Artwork
                    Image(
                        painter = painterResource(id = R.drawable.img_futivexa_banner),
                        contentDescription = "FUTIVEXA AI Studio",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp),
                        contentScale = ContentScale.Crop
                    )

                    // Gradient overlay
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, Color(0xCC0F172A))
                                )
                            )
                    )

                    // Content on banner
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Spacer(modifier = Modifier.height(60.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_futivexa_logo),
                                contentDescription = "Logo",
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(10.dp))
                            )
                            Column {
                                Text(
                                    text = "FUTIVEXA AI",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                                Text(
                                    text = "Create • Edit • Grow",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = FutivexaCyanLight,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Credits Counter Pill
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Bolt,
                                        contentDescription = "Credits",
                                        tint = if (isPremium) AccentGold else MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Column {
                                        Text(
                                            text = if (isPremium) "Premium Member" else "AI Generations Left",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = if (isPremium) "Unlimited Access" else "$creditsRemaining / $maxCredits Remaining Today",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }

                                if (!isPremium) {
                                    FilledTonalButton(
                                        onClick = { showRewardAdDialog = true },
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.testTag("earn_credits_btn")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "+3 Credits",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section Title: Creation Modules
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "AI Creation Studio",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "5 Power Tools",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        // The 5 Main Module Cards
        items(modules) { module ->
            ModuleCard(
                module = module,
                onClick = { onNavigateToModule(module.id) }
            )
        }

        // Recent Projects Section
        if (recentProjects.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recent Projects",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${recentProjects.size} saved",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(recentProjects.take(5)) { project ->
                        RecentProjectCard(
                            project = project,
                            onClick = { onNavigateToProject(project.id) }
                        )
                    }
                }
            }
        }

        // Ad Banner at bottom
        item {
            Spacer(modifier = Modifier.height(16.dp))
            AdBannerView(isPremium = isPremium)
        }
    }
}

@Composable
fun ModuleCard(
    module: ModuleCardInfo,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 7.dp)
            .clickable(onClick = onClick)
            .testTag("module_card_${module.id}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Gradient Icon Box
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Brush.linearGradient(module.gradient)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = module.icon,
                    contentDescription = module.title,
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }

            // Info Column
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = module.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    if (module.badge.isNotBlank()) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = module.gradient.first().copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = module.badge,
                                style = MaterialTheme.typography.labelSmall,
                                color = module.gradient.first(),
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Text(
                    text = module.urduTitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = module.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = "Open",
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun RecentProjectCard(
    project: ProjectEntity,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(160.dp)
            .clickable(onClick = onClick)
            .testTag("recent_project_${project.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF0F172A)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = when (project.type) {
                        "BUSINESS_AD" -> "🏷️"
                        "WHATSAPP_STATUS" -> "💬"
                        "VIDEO" -> "🎬"
                        "URDU_POST" -> "✍️"
                        else -> "💡"
                    },
                    fontSize = 32.sp
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = project.title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = project.aspectRatio,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}
