package com.example.features.whatsapp

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.core.ads.AdBannerView
import com.example.core.network.AiResult
import com.example.core.network.GeminiService
import com.example.core.storage.CreditManager
import com.example.core.storage.ProjectEntity
import com.example.core.storage.ProjectRepository
import com.example.core.utils.ImageExportHelper
import com.example.ui.theme.FutivexaCyan
import com.example.ui.theme.FutivexaEmerald
import com.example.ui.theme.FutivexaViolet
import kotlinx.coroutines.launch

data class WhatsAppType(val id: String, val name: String, val urduName: String, val defaultTitle: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WhatsAppCreatorScreen(
    geminiService: GeminiService,
    creditManager: CreditManager,
    projectRepository: ProjectRepository,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val isPremium by creditManager.isPremium.collectAsState()

    val options = remember {
        listOf(
            WhatsAppType("status", "Status (9:16)", "اسٹیٹس 9:16", "🔥 Big Weekend Flash Sale!"),
            WhatsAppType("product", "Product Ad", "پراڈکٹ اشتہار", "✨ New Arrival in Stock!"),
            WhatsAppType("sale", "Sale Alert", "سیل اعلان", "🎉 Flat 40% Off Everything!"),
            WhatsAppType("discount", "Discount Voucher", "ڈسکاؤنٹ میسج", "🎁 Special VIP Discount For You!"),
            WhatsAppType("new_item", "New Arrival", "نئی پراڈکٹ کا اعلان", "🚀 Brand New Drop Just Landed!"),
            WhatsAppType("customer", "Customer Message", "گاہک کا شکریہ میسج", "❤️ Thank You For Shopping With Us!"),
            WhatsAppType("promo", "Business Promo", "بزنس تشہیر", "📈 Grow With Apex Services")
        )
    }

    var selectedType by remember { mutableStateOf(options[0]) }
    var isUrdu by remember { mutableStateOf(false) }
    var promptDetails by remember { mutableStateOf("Limited pieces left. Order before stock finishes. Free cash on delivery across city.") }
    var statusTitle by remember { mutableStateOf(options[0].defaultTitle) }
    var statusMessage by remember {
        mutableStateOf("🌟 Exclusive WhatsApp Community Deal!\nGet flat 30% OFF today only.\nTap reply or send a message to book your order right now! 🚚📦")
    }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var isAiGenerating by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successToast by remember { mutableStateOf<String?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) selectedImageUri = uri
    }

    val whatsappGradients = remember {
        listOf(
            Brush.verticalGradient(listOf(Color(0xFF075E54), Color(0xFF128C7E), Color(0xFF0F172A))),
            Brush.verticalGradient(listOf(Color(0xFF1E1B4B), Color(0xFF312E81), Color(0xFF0F172A))),
            Brush.verticalGradient(listOf(Color(0xFF831843), Color(0xFFBE185D), Color(0xFF0F172A)))
        )
    }
    var selectedGradientIndex by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("WhatsApp Creator", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(
                            text = if (isUrdu) "واٹس ایپ اسٹیٹس اور پیغامات" else "9:16 Status & Direct Messaging",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    FilterChip(
                        selected = isUrdu,
                        onClick = { isUrdu = !isUrdu },
                        label = { Text(if (isUrdu) "اردو" else "English", fontWeight = FontWeight.Bold) },
                        modifier = Modifier.padding(end = 8.dp)
                    )
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Category Chips Row
            Text(
                text = "Select Content Type",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                options.take(4).forEach { option ->
                    FilterChip(
                        selected = selectedType.id == option.id,
                        onClick = {
                            selectedType = option
                            statusTitle = option.defaultTitle
                        },
                        label = { Text(if (isUrdu) option.urduName else option.name) }
                    )
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                options.drop(4).forEach { option ->
                    FilterChip(
                        selected = selectedType.id == option.id,
                        onClick = {
                            selectedType = option
                            statusTitle = option.defaultTitle
                        },
                        label = { Text(if (isUrdu) option.urduName else option.name) }
                    )
                }
            }

            // 9:16 WhatsApp Status Card Preview
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("whatsapp_preview_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "9:16 WHATSAPP STATUS PREVIEW",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // 9:16 Frame
                    Box(
                        modifier = Modifier
                            .width(220.dp)
                            .height(390.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(whatsappGradients[selectedGradientIndex])
                            .border(2.dp, Color(0xFF25D366).copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                            .padding(16.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.SpaceBetween,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Top Bar simulated status indicator
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(3.dp)
                                        .background(Color.White.copy(alpha = 0.8f), CircleShape)
                                )
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(3.dp)
                                        .background(Color.White.copy(alpha = 0.3f), CircleShape)
                                )
                            }

                            // Optional photo
                            if (selectedImageUri != null) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(130.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                ) {
                                    AsyncImage(
                                        model = selectedImageUri,
                                        contentDescription = "Status Photo",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                }
                            } else {
                                Icon(
                                    imageVector = Icons.Default.ChatBubble,
                                    contentDescription = null,
                                    tint = Color.White.copy(alpha = 0.3f),
                                    modifier = Modifier.size(48.dp)
                                )
                            }

                            // Status Text
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = statusTitle,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = statusMessage,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White.copy(alpha = 0.9f),
                                    textAlign = TextAlign.Center,
                                    lineHeight = 16.sp
                                )
                            }

                            // Bottom reply badge
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = Color.Black.copy(alpha = 0.3f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Send,
                                        contentDescription = null,
                                        tint = Color(0xFF25D366),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "Reply to Order",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }
                        ) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (selectedImageUri == null) "Add Photo" else "Change Photo")
                        }

                        OutlinedButton(
                            onClick = {
                                selectedGradientIndex = (selectedGradientIndex + 1) % whatsappGradients.size
                            }
                        ) {
                            Icon(Icons.Default.ColorLens, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Theme")
                        }
                    }
                }
            }

            // AI Content Generation Inputs
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Customize Content & Message",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    OutlinedTextField(
                        value = statusTitle,
                        onValueChange = { statusTitle = it },
                        label = { Text("Status Headline / Title") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = promptDetails,
                        onValueChange = { promptDetails = it },
                        label = { Text("What should the message say?") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )

                    Button(
                        onClick = {
                            if (!creditManager.hasCredits()) {
                                errorMessage = "No AI credits remaining today. Watch a rewarded ad to get +3 credits!"
                                return@Button
                            }
                            isAiGenerating = true
                            errorMessage = null
                            coroutineScope.launch {
                                val prompt = if (isUrdu) {
                                    "واٹس ایپ کے لیے ایک بہترین اور پرکشش ${selectedType.urduName} تیار کریں۔ موضوع: $statusTitle ، تفصیلات: $promptDetails ۔ ایموجیز اور واضح الفاظ شامل کریں۔"
                                } else {
                                    "Generate an engaging WhatsApp ${selectedType.name} text with emojis, clear hook, attractive offer details, and high-response call to action for: $statusTitle with details: $promptDetails."
                                }

                                val result = geminiService.generateContent(
                                    prompt = prompt,
                                    systemInstruction = "You are a professional WhatsApp marketing and copywriting specialist."
                                )

                                isAiGenerating = false
                                creditManager.consumeCredit()

                                when (result) {
                                    is AiResult.Success -> {
                                        statusMessage = result.data
                                        successToast = "WhatsApp content generated!"
                                    }
                                    is AiResult.Error -> {
                                        errorMessage = if (isUrdu) result.urduMessage else result.message
                                    }
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("ai_generate_whatsapp_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
                    ) {
                        if (isAiGenerating) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Generating Content...", color = Color.White)
                        } else {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("AI Generate WhatsApp Text", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }

                    OutlinedTextField(
                        value = statusMessage,
                        onValueChange = { statusMessage = it },
                        label = { Text("Full Message Text (Editable)") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 4
                    )
                }
            }

            // Quick Sharing Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        val full = "$statusTitle\n\n$statusMessage\n\n— Generated via FUTIVEXA AI"
                        ImageExportHelper.copyToClipboard(context, full)
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Copy", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                Button(
                    onClick = {
                        val full = "$statusTitle\n\n$statusMessage\n\n— Generated via FUTIVEXA AI"
                        ImageExportHelper.shareToWhatsApp(context, full)
                    },
                    modifier = Modifier.weight(1.5f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
                ) {
                    Icon(Icons.Default.Send, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Share to WhatsApp", color = Color.White, fontWeight = FontWeight.Bold)
                }

                IconButton(
                    onClick = {
                        coroutineScope.launch {
                            val entity = ProjectEntity(
                                title = statusTitle,
                                type = "WHATSAPP_STATUS",
                                subtitle = selectedType.name,
                                aspectRatio = "9:16",
                                contentData = statusMessage,
                                language = if (isUrdu) "Urdu" else "English"
                            )
                            projectRepository.saveProject(entity)
                            successToast = "Saved to Projects!"
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(12.dp))
                ) {
                    Icon(Icons.Default.Save, contentDescription = "Save", tint = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }

            // Toast / Error
            errorMessage?.let { err ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Text(text = err, color = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.padding(12.dp))
                }
            }

            successToast?.let { msg ->
                Card(colors = CardDefaults.cardColors(containerColor = FutivexaEmerald.copy(alpha = 0.2f))) {
                    Text(text = msg, color = FutivexaEmerald, fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp))
                }
            }

            AdBannerView(isPremium = isPremium)
        }
    }
}
