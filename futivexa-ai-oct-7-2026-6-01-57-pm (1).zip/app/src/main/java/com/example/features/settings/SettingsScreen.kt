package com.example.features.settings

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.core.config.AppConfig
import com.example.core.storage.CreditManager
import com.example.ui.theme.AccentGold
import com.example.ui.theme.FutivexaCyan
import com.example.ui.theme.FutivexaEmerald
import com.example.ui.theme.FutivexaViolet

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    creditManager: CreditManager,
    isDarkTheme: Boolean,
    onToggleDarkTheme: (Boolean) -> Unit,
    currentLanguage: String,
    onChangeLanguage: (String) -> Unit
) {
    val context = LocalContext.current
    val creditsRemaining by creditManager.creditsRemaining.collectAsState()
    val maxCredits by creditManager.maxDailyLimit.collectAsState()
    val isPremium by creditManager.isPremium.collectAsState()

    var isDevMode by remember { mutableStateOf(AppConfig.isDeveloperMode(context)) }
    var devTapCount by remember { mutableIntStateOf(0) }

    // Developer config form fields
    var devApiKey by remember { mutableStateOf(AppConfig.getApiKey(context)) }
    var devBannerId by remember { mutableStateOf(AppConfig.getBannerAdId(context)) }
    var devInterstitialId by remember { mutableStateOf(AppConfig.getInterstitialAdId(context)) }
    var devRewardedId by remember { mutableStateOf(AppConfig.getRewardedAdId(context)) }

    // Dialog state
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showTermsDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Brand Info Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_futivexa_logo),
                        contentDescription = "FUTIVEXA AI Logo",
                        modifier = Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(12.dp))
                    )
                    Column {
                        Text("FUTIVEXA AI", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Create • Edit • Grow", style = MaterialTheme.typography.bodySmall, color = FutivexaCyan, fontWeight = FontWeight.Medium)
                        Text("Commercial v1.0 • All-In-One AI Studio", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            // AI Usage & Subscription Plan Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("AI Usage & Tier", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(if (isPremium) "PRO Tier (Ad-Free)" else "Free Tier ($creditsRemaining / $maxCredits Remaining)", fontWeight = FontWeight.SemiBold)
                            Text(
                                text = if (isPremium) "Unlimited AI generations & priority speed" else "10 free AI generations per day",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Switch(
                            checked = isPremium,
                            onCheckedChange = { creditManager.setPremium(it) }
                        )
                    }

                    if (!isPremium) {
                        Button(
                            onClick = { creditManager.addRewardCredits(3) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = FutivexaViolet)
                        ) {
                            Icon(Icons.Default.Bolt, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Top Up Credits (+3 Generations)")
                        }
                    }
                }
            }

            // App Preferences Card (Theme & Language)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("Preferences", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                    // Dark Theme Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DarkMode, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Dark Theme")
                        }
                        Switch(
                            checked = isDarkTheme,
                            onCheckedChange = onToggleDarkTheme
                        )
                    }

                    HorizontalDivider()

                    // Language Option
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Language, contentDescription = null, tint = FutivexaEmerald)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Primary Language")
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(
                                selected = currentLanguage == "English",
                                onClick = { onChangeLanguage("English") },
                                label = { Text("English") }
                            )
                            FilterChip(
                                selected = currentLanguage == "Urdu",
                                onClick = { onChangeLanguage("Urdu") },
                                label = { Text("اردو") }
                            )
                        }
                    }
                }
            }

            // Legal & About Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Information & Support", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                    ListItem(
                        headlineContent = { Text("Privacy Policy") },
                        leadingContent = { Icon(Icons.Default.Security, contentDescription = null) },
                        modifier = Modifier.clickable { showPrivacyDialog = true }
                    )
                    ListItem(
                        headlineContent = { Text("Terms of Service") },
                        leadingContent = { Icon(Icons.Default.Description, contentDescription = null) },
                        modifier = Modifier.clickable { showTermsDialog = true }
                    )
                    ListItem(
                        headlineContent = { Text("About FUTIVEXA AI") },
                        leadingContent = { Icon(Icons.Default.Info, contentDescription = null) },
                        modifier = Modifier.clickable { showAboutDialog = true }
                    )
                }
            }

            // Developer Mode Secret Tap Trigger on Version Label
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        devTapCount++
                        if (devTapCount >= 5) {
                            isDevMode = !isDevMode
                            AppConfig.setDeveloperMode(context, isDevMode)
                            devTapCount = 0
                            Toast.makeText(
                                context,
                                if (isDevMode) "Developer Configuration Unlocked" else "Developer Mode Hidden",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Build 1.0.1 (FUTIVEXA AI Production Core)",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
            }

            // DEVELOPER / CONFIGURATION SECTION (HIDDEN FROM NORMAL USERS)
            AnimatedVisibility(visible = isDevMode) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dev_config_section"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DeveloperMode, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Developer & ID Management Portal", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }

                        Text(
                            text = "This section is reserved for developer configuration. Replace placeholder unit IDs before production release. API keys are injected securely via AI Studio secrets.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        // AI API Key (Masked placeholder display)
                        OutlinedTextField(
                            value = if (devApiKey.isNotBlank()) "••••••••••••${devApiKey.takeLast(4)}" else AppConfig.AI_API_KEY_PLACEHOLDER,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("AI_API_KEY") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        // AdMob App ID
                        OutlinedTextField(
                            value = AppConfig.TEST_ADMOB_APP_ID,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("ADMOB_APP_ID (Google Official Test ID)") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        // AdMob Banner ID
                        OutlinedTextField(
                            value = devBannerId,
                            onValueChange = { devBannerId = it },
                            label = { Text("ADMOB_BANNER_ID") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        // AdMob Interstitial ID
                        OutlinedTextField(
                            value = devInterstitialId,
                            onValueChange = { devInterstitialId = it },
                            label = { Text("ADMOB_INTERSTITIAL_ID") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        // AdMob Rewarded ID
                        OutlinedTextField(
                            value = devRewardedId,
                            onValueChange = { devRewardedId = it },
                            label = { Text("ADMOB_REWARDED_ID") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        // Analytics ID
                        OutlinedTextField(
                            value = AppConfig.TEST_ANALYTICS_ID,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("ANALYTICS_ID") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Button(
                            onClick = {
                                AppConfig.updateAdIds(context, devBannerId, devInterstitialId, devRewardedId)
                                Toast.makeText(context, "Configurations Saved Successfully", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Save Configuration")
                        }
                    }
                }
            }
        }
    }

    // Privacy Policy Dialog
    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text("Privacy Policy") },
            text = {
                Text(
                    "FUTIVEXA AI respects user privacy. All business designs, exported images, and custom project records are saved locally in your device's private database. No confidential customer records or photos are uploaded to external tracking servers without user permission."
                )
            },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) { Text("OK") }
            }
        )
    }

    // Terms Dialog
    if (showTermsDialog) {
        AlertDialog(
            onDismissRequest = { showTermsDialog = false },
            title = { Text("Terms of Service") },
            text = {
                Text(
                    "By using FUTIVEXA AI ('Create • Edit • Grow'), you agree that generated content is intended for promotional and creative purposes. You retain full commercial ownership of your finished promotional designs."
                )
            },
            confirmButton = {
                TextButton(onClick = { showTermsDialog = false }) { Text("OK") }
            }
        )
    }

    // About Dialog
    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = { Text("About FUTIVEXA AI") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Brand: FUTIVEXA AI", fontWeight = FontWeight.Bold)
                    Text("Tagline: Create • Edit • Grow")
                    Text("Version: 1.0 (Production Core)")
                    Text("FUTIVEXA AI is designed as a long-term all-in-one AI content, editing, and small-business growth platform.")
                }
            },
            confirmButton = {
                TextButton(onClick = { showAboutDialog = false }) { Text("Done") }
            }
        )
    }
}
