package com.example.features.video

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.core.ads.AdBannerView
import com.example.core.storage.CreditManager
import com.example.core.storage.ProjectEntity
import com.example.core.storage.ProjectRepository
import com.example.core.utils.ImageExportHelper
import com.example.ui.theme.AccentGold
import com.example.ui.theme.FutivexaCyan
import com.example.ui.theme.FutivexaEmerald
import com.example.ui.theme.FutivexaViolet
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class VideoTemplate(val name: String, val badge: String, val bgGradients: List<Color>)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiVideoMakerScreen(
    creditManager: CreditManager,
    projectRepository: ProjectRepository,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val isPremium by creditManager.isPremium.collectAsState()

    // Config state
    var selectedRatio by remember { mutableStateOf("9:16") }
    var headlineText by remember { mutableStateOf("NEW EXCLUSIVE ARRIVAL") }
    var priceOfferText by remember { mutableStateOf("50% OFF TODAY ONLY") }
    var selectedDuration by remember { mutableIntStateOf(10) } // seconds
    var selectedTransition by remember { mutableStateOf("Ken Burns") }
    var selectedSoundtrack by remember { mutableStateOf("Lo-Fi Hustle") }

    val templates = remember {
        listOf(
            VideoTemplate("Pulse Beat", "TRENDING", listOf(Color(0xFF6366F1), Color(0xFF0F172A))),
            VideoTemplate("Cinematic Zoom", "SMOOTH", listOf(Color(0xFF0E7490), Color(0xFF0B0F19))),
            VideoTemplate("Neon Glow", "VIBRANT", listOf(Color(0xFF8B5CF6), Color(0xFF0F172A))),
            VideoTemplate("Minimal Story", "CLEAN", listOf(Color(0xFF334155), Color(0xFF0F172A)))
        )
    }
    var selectedTemplateIndex by remember { mutableIntStateOf(0) }

    // Multi-photo list (supports multiple URIs)
    val photoUris = remember { mutableStateListOf<Uri>() }

    val multiPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 6)
    ) { uris ->
        if (uris.isNotEmpty()) {
            photoUris.clear()
            photoUris.addAll(uris)
        }
    }

    // Video Player Simulation State
    var isPlaying by remember { mutableStateOf(true) }
    var activeFrameIndex by remember { mutableIntStateOf(0) }
    var isExporting by remember { mutableStateOf(false) }
    var exportProgress by remember { mutableFloatStateOf(0f) }
    var exportCompletedDialog by remember { mutableStateOf(false) }
    var successToast by remember { mutableStateOf<String?>(null) }

    // Frame Animator for live preview
    val totalSlots = if (photoUris.isEmpty()) 3 else photoUris.size
    LaunchedEffect(isPlaying, totalSlots) {
        while (isPlaying) {
            delay(2200)
            activeFrameIndex = (activeFrameIndex + 1) % totalSlots
        }
    }

    val ratioAspect = when (selectedRatio) {
        "1:1" -> 1f
        "16:9" -> 16f / 9f
        else -> 9f / 16f
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("AI Video Maker", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(
                            text = "9:16 Shorts & Multi-Photo Video",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Live Video Player Box
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("video_player_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "LIVE VIDEO PLAYER PREVIEW ($selectedRatio)",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Simulated Video Viewport
                    Box(
                        modifier = Modifier
                            .width(if (selectedRatio == "16:9") 280.dp else if (selectedRatio == "1:1") 240.dp else 200.dp)
                            .aspectRatio(ratioAspect)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Brush.verticalGradient(templates[selectedTemplateIndex].bgGradients))
                            .border(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.SpaceBetween,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Video Header Pill
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color.Black.copy(alpha = 0.5f)
                                ) {
                                    Text(
                                        text = "FUTIVEXA AI",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }

                                if (priceOfferText.isNotBlank()) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = FutivexaEmerald
                                    ) {
                                        Text(
                                            text = priceOfferText,
                                            color = Color.White,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }

                            // Animated Frame Image
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                AnimatedContent(
                                    targetState = activeFrameIndex,
                                    transitionSpec = {
                                        fadeIn(animationSpec = tween(500)) togetherWith
                                                fadeOut(animationSpec = tween(500))
                                    },
                                    label = "frame_transition"
                                ) { frameIdx ->
                                    if (photoUris.isNotEmpty() && frameIdx < photoUris.size) {
                                        AsyncImage(
                                            model = photoUris[frameIdx],
                                            contentDescription = "Frame $frameIdx",
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .clip(RoundedCornerShape(12.dp)),
                                            contentScale = ContentScale.Crop
                                        )
                                    } else {
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            Icon(
                                                imageVector = when (frameIdx % 3) {
                                                    0 -> Icons.Default.FlashOn
                                                    1 -> Icons.Default.ShoppingBag
                                                    else -> Icons.Default.Star
                                                },
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(48.dp)
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "Frame ${frameIdx + 1}",
                                                color = Color.White.copy(alpha = 0.8f),
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }
                            }

                            // Dynamic Text Overlay
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color.Black.copy(alpha = 0.6f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(6.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = headlineText,
                                        color = AccentGold,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        textAlign = TextAlign.Center
                                    )
                                    Text(
                                        text = "🎵 $selectedSoundtrack",
                                        color = Color.White.copy(alpha = 0.7f),
                                        fontSize = 9.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Player Controls Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { isPlaying = !isPlaying }) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Play / Pause",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }

                        // Aspect ratio chips
                        listOf("9:16", "1:1", "16:9").forEach { ratio ->
                            FilterChip(
                                selected = selectedRatio == ratio,
                                onClick = { selectedRatio = ratio },
                                label = { Text(ratio) }
                            )
                        }
                    }
                }
            }

            // Photos Selector Row
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Product Photos (${photoUris.size}/6)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        TextButton(
                            onClick = {
                                multiPhotoPicker.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier.testTag("upload_video_photos_btn")
                        ) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Upload Photos")
                        }
                    }

                    if (photoUris.isEmpty()) {
                        Text(
                            text = "Tap 'Upload Photos' to select multiple product pictures from gallery, or preview using default showcase templates.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            itemsIndexed(photoUris) { index, uri ->
                                Box(
                                    modifier = Modifier
                                        .size(68.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .border(
                                            if (index == activeFrameIndex) 2.dp else 1.dp,
                                            if (index == activeFrameIndex) MaterialTheme.colorScheme.primary else Color.Gray,
                                            RoundedCornerShape(8.dp)
                                        )
                                ) {
                                    AsyncImage(
                                        model = uri,
                                        contentDescription = "Slot $index",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Video Settings & Overlays
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Text & Offer Overlays",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    OutlinedTextField(
                        value = headlineText,
                        onValueChange = { headlineText = it },
                        label = { Text("Video Headline / Promo Text") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = priceOfferText,
                        onValueChange = { priceOfferText = it },
                        label = { Text("Price Badge / Offer Callout") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Template & Transitions
                    Text(text = "Style Template", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        templates.forEachIndexed { idx, t ->
                            FilterChip(
                                selected = selectedTemplateIndex == idx,
                                onClick = { selectedTemplateIndex = idx },
                                label = { Text(t.name) }
                            )
                        }
                    }

                    // Transition Selector
                    Text(text = "Transition Effect", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Ken Burns", "Slide Up", "Fade", "Zoom In").forEach { trans ->
                            FilterChip(
                                selected = selectedTransition == trans,
                                onClick = { selectedTransition = trans },
                                label = { Text(trans) }
                            )
                        }
                    }

                    // Music Selector
                    Text(text = "Background Beat Track", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Lo-Fi Hustle", "Neon Pulse", "Corporate Beat", "Aesthetic Chill").forEach { track ->
                            FilterChip(
                                selected = selectedSoundtrack == track,
                                onClick = { selectedSoundtrack = track },
                                label = { Text(track) }
                            )
                        }
                    }

                    // Duration Selector
                    Text(text = "Duration", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(5, 10, 15, 30).forEach { dur ->
                            FilterChip(
                                selected = selectedDuration == dur,
                                onClick = { selectedDuration = dur },
                                label = { Text("${dur}s") }
                            )
                        }
                    }
                }
            }

            // Export Video Action Button
            Button(
                onClick = {
                    isExporting = true
                    exportProgress = 0f
                    coroutineScope.launch {
                        while (exportProgress < 1f) {
                            delay(120)
                            exportProgress += 0.05f
                        }
                        isExporting = false
                        exportCompletedDialog = true

                        // Save to projects
                        val entity = ProjectEntity(
                            title = headlineText.ifBlank { "AI Short Video" },
                            type = "VIDEO",
                            subtitle = "${selectedDuration}s • $selectedRatio",
                            aspectRatio = selectedRatio,
                            contentData = "$priceOfferText | $selectedSoundtrack | $selectedTransition"
                        )
                        projectRepository.saveProject(entity)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("export_video_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = FutivexaViolet),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.MovieCreation, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Export Short Video (${selectedDuration}s)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }

            // Rendering Dialog
            if (isExporting) {
                AlertDialog(
                    onDismissRequest = {},
                    title = { Text("Rendering AI Video...") },
                    text = {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text("Stitching frames with ${selectedTransition} & audio...")
                            LinearProgressIndicator(
                                progress = { exportProgress },
                                modifier = Modifier.fillMaxWidth(),
                                color = FutivexaViolet
                            )
                            Text("${(exportProgress * 100).toInt()}% Complete", fontWeight = FontWeight.Bold)
                        }
                    },
                    confirmButton = {}
                )
            }

            // Export Complete Dialog
            if (exportCompletedDialog) {
                AlertDialog(
                    onDismissRequest = { exportCompletedDialog = false },
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = FutivexaEmerald)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Video Rendered Successfully!")
                        }
                    },
                    text = {
                        Text("Your $selectedRatio video has been compiled with $selectedSoundtrack track and saved to your project library. Ready to share on WhatsApp or Instagram Reels!")
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                exportCompletedDialog = false
                                ImageExportHelper.shareText(
                                    context,
                                    "Check out my new video created on FUTIVEXA AI: $headlineText ($priceOfferText)",
                                    "Share Video"
                                )
                            }
                        ) {
                            Text("Share Video")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { exportCompletedDialog = false }) {
                            Text("Done")
                        }
                    }
                )
            }

            AdBannerView(isPremium = isPremium)
        }
    }
}
