package com.example.core.storage

import kotlinx.coroutines.flow.Flow

class ProjectRepository(private val dao: ProjectDao) {
    val allProjects: Flow<List<ProjectEntity>> = dao.getAllProjects()
    val favoriteProjects: Flow<List<ProjectEntity>> = dao.getFavoriteProjects()

    fun getProjectsByType(type: String): Flow<List<ProjectEntity>> = dao.getProjectsByType(type)

    suspend fun getProjectById(id: Long): ProjectEntity? = dao.getProjectById(id)

    suspend fun saveProject(project: ProjectEntity): Long = dao.insertProject(project)

    suspend fun deleteProject(id: Long) = dao.deleteProjectById(id)

    suspend fun toggleFavorite(id: Long) = dao.toggleFavorite(id)

    suspend fun renameProject(id: Long, newTitle: String) = dao.renameProject(id, newTitle)
}
