package com.example.core.config

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig

/**
 * FUTIVEXA AI Configuration & ID Management
 *
 * All service IDs, ad unit IDs, and API placeholders are organized here.
 * Real secrets are kept separate and not exposed to regular users in the UI.
 * Official Google AdMob test IDs are used for safe development.
 */
object AppConfig {

    // --- Google AdMob Official Test IDs (Never use production IDs during testing) ---
    // Source: https://developers.google.com/admob/android/test-ads
    const val TEST_ADMOB_APP_ID = "ca-app-pub-3940256099942544~3347511713"
    const val TEST_ADMOB_BANNER_ID = "ca-app-pub-3940256099942544/6300978111"
    const val TEST_ADMOB_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"
    const val TEST_ADMOB_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"
    const val TEST_ANALYTICS_ID = "G-FUTIVEXA-DEV-101"

    // Placeholders for Production Release (Replace before publishing):
    const val PROD_ADMOB_APP_ID_PLACEHOLDER = "[ADD_YOUR_ADMOB_APP_ID_HERE]"
    const val PROD_ADMOB_BANNER_ID_PLACEHOLDER = "[ADD_YOUR_BANNER_AD_UNIT_ID_HERE]"
    const val PROD_ADMOB_INTERSTITIAL_ID_PLACEHOLDER = "[ADD_YOUR_INTERSTITIAL_AD_UNIT_ID_HERE]"
    const val PROD_ADMOB_REWARDED_ID_PLACEHOLDER = "[ADD_YOUR_REWARDED_AD_UNIT_ID_HERE]"
    const val PROD_ANALYTICS_ID_PLACEHOLDER = "[ADD_YOUR_ANALYTICS_ID_HERE]"
    const val AI_API_KEY_PLACEHOLDER = "[ADD_YOUR_AI_API_KEY_HERE]"

    // SharedPreferences keys for developer overrides during testing
    private const val PREFS_NAME = "futivexa_dev_config"
    private const val KEY_CUSTOM_API_KEY = "custom_gemini_api_key"
    private const val KEY_USE_TEST_ADS = "use_test_ads"
    private const val KEY_CUSTOM_BANNER_ID = "custom_banner_id"
    private const val KEY_CUSTOM_INTERSTITIAL_ID = "custom_interstitial_id"
    private const val KEY_CUSTOM_REWARDED_ID = "custom_rewarded_id"
    private const val KEY_DEVELOPER_MODE = "developer_mode_active"

    fun getApiKey(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val customKey = prefs.getString(KEY_CUSTOM_API_KEY, "") ?: ""
        if (customKey.isNotBlank()) return customKey
        
        // Fallback to injected BuildConfig secret
        return try {
            val key = BuildConfig.GEMINI_API_KEY
            if (key.isNotBlank() && key != "MY_GEMINI_API_KEY") key else ""
        } catch (_: Exception) {
            ""
        }
    }

    fun setCustomApiKey(context: Context, key: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_CUSTOM_API_KEY, key.trim()).apply()
    }

    fun isDeveloperMode(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_DEVELOPER_MODE, false)
    }

    fun setDeveloperMode(context: Context, enabled: Boolean) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_DEVELOPER_MODE, enabled).apply()
    }

    fun getBannerAdId(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val custom = prefs.getString(KEY_CUSTOM_BANNER_ID, "") ?: ""
        return if (custom.isNotBlank()) custom else TEST_ADMOB_BANNER_ID
    }

    fun getInterstitialAdId(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val custom = prefs.getString(KEY_CUSTOM_INTERSTITIAL_ID, "") ?: ""
        return if (custom.isNotBlank()) custom else TEST_ADMOB_INTERSTITIAL_ID
    }

    fun getRewardedAdId(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val custom = prefs.getString(KEY_CUSTOM_REWARDED_ID, "") ?: ""
        return if (custom.isNotBlank()) custom else TEST_ADMOB_REWARDED_ID
    }

    fun updateAdIds(context: Context, banner: String, interstitial: String, rewarded: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_CUSTOM_BANNER_ID, banner.trim())
            .putString(KEY_CUSTOM_INTERSTITIAL_ID, interstitial.trim())
            .putString(KEY_CUSTOM_REWARDED_ID, rewarded.trim())
            .apply()
    }
}
