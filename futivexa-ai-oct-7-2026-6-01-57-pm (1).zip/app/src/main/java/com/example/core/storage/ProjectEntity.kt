package com.example.core.storage

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val type: String, // "BUSINESS_AD", "WHATSAPP_STATUS", "VIDEO", "URDU_POST", "ASSISTANT_NOTE"
    val subtitle: String,
    val aspectRatio: String = "1:1",
    val contentData: String = "",
    val language: String = "English",
    val isFavorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
