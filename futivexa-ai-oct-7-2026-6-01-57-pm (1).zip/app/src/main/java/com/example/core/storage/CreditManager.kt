package com.example.core.storage

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CreditManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("futivexa_credits_pref", Context.MODE_PRIVATE)

    companion object {
        const val DEFAULT_DAILY_LIMIT = 10
        const val REWARDED_BONUS_CREDITS = 3
    }

    private val _creditsRemaining = MutableStateFlow(getRemainingCreditsInternal())
    val creditsRemaining: StateFlow<Int> = _creditsRemaining.asStateFlow()

    private val _maxDailyLimit = MutableStateFlow(getMaxLimitInternal())
    val maxDailyLimit: StateFlow<Int> = _maxDailyLimit.asStateFlow()

    private val _isPremium = MutableStateFlow(prefs.getBoolean("is_premium_tier", false))
    val isPremium: StateFlow<Boolean> = _isPremium.asStateFlow()

    init {
        checkDailyReset()
    }

    private fun checkDailyReset() {
        val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val lastDate = prefs.getString("last_credit_date", "")

        if (today != lastDate) {
            val max = getMaxLimitInternal()
            prefs.edit()
                .putString("last_credit_date", today)
                .putInt("remaining_credits", max)
                .apply()
            _creditsRemaining.value = max
        }
    }

    private fun getRemainingCreditsInternal(): Int {
        val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val lastDate = prefs.getString("last_credit_date", "")
        if (today != lastDate) {
            val max = getMaxLimitInternal()
            prefs.edit()
                .putString("last_credit_date", today)
                .putInt("remaining_credits", max)
                .apply()
            return max
        }
        return prefs.getInt("remaining_credits", DEFAULT_DAILY_LIMIT)
    }

    private fun getMaxLimitInternal(): Int {
        return prefs.getInt("config_max_daily_credits", DEFAULT_DAILY_LIMIT)
    }

    fun hasCredits(): Boolean {
        if (_isPremium.value) return true
        return _creditsRemaining.value > 0
    }

    fun consumeCredit(): Boolean {
        if (_isPremium.value) return true
        checkDailyReset()
        val current = _creditsRemaining.value
        if (current > 0) {
            val updated = current - 1
            prefs.edit().putInt("remaining_credits", updated).apply()
            _creditsRemaining.value = updated
            return true
        }
        return false
    }

    fun addRewardCredits(amount: Int = REWARDED_BONUS_CREDITS) {
        val current = _creditsRemaining.value
        val updated = current + amount
        prefs.edit().putInt("remaining_credits", updated).apply()
        _creditsRemaining.value = updated
    }

    fun setMaxDailyCredits(limit: Int) {
        prefs.edit().putInt("config_max_daily_credits", limit).apply()
        _maxDailyLimit.value = limit
    }

    fun setPremium(premium: Boolean) {
        prefs.edit().putBoolean("is_premium_tier", premium).apply()
        _isPremium.value = premium
    }
}
