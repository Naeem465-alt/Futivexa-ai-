package com.example.core.utils

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

object ImageExportHelper {

    fun copyToClipboard(context: Context, text: String, label: String = "FUTIVEXA AI") {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "Copied to clipboard! / کلپ بورڈ میں کاپی ہو گیا", Toast.LENGTH_SHORT).show()
    }

    fun shareText(context: Context, text: String, title: String = "Share via FUTIVEXA AI") {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(Intent.createChooser(intent, title))
    }

    fun shareToWhatsApp(context: Context, text: String) {
        val whatsappIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
            setPackage("com.whatsapp")
        }
        try {
            context.startActivity(whatsappIntent)
        } catch (_: Exception) {
            // WhatsApp not installed, fallback to system chooser
            shareText(context, text, "Share via WhatsApp")
        }
    }

    /**
     * Creates and saves a high quality banner bitmap locally
     */
    fun createPosterBitmap(
        title: String,
        subtitle: String,
        price: String,
        discount: String,
        businessName: String,
        phone: String,
        width: Int = 1080,
        height: Int = 1080,
        isUrdu: Boolean = false
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Gradient dark background
        val bgPaint = Paint().apply {
            color = Color.parseColor("#0F172A")
            isAntiAlias = true
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Accent header bar
        val accentPaint = Paint().apply {
            color = Color.parseColor("#6366F1")
            isAntiAlias = true
        }
        canvas.drawRect(0f, 0f, width.toFloat(), 120f, accentPaint)

        // Branding
        val brandPaint = Paint().apply {
            color = Color.WHITE
            textSize = 42f
            isFakeBoldText = true
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("FUTIVEXA AI • $businessName", width / 2f, 75f, brandPaint)

        // Discount badge if available
        if (discount.isNotBlank()) {
            val badgeBg = Paint().apply {
                color = Color.parseColor("#10B981")
                isAntiAlias = true
            }
            canvas.drawRoundRect(60f, 160f, 420f, 250f, 24f, 24f, badgeBg)
            val badgeText = Paint().apply {
                color = Color.WHITE
                textSize = 38f
                isFakeBoldText = true
                isAntiAlias = true
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("SPECIAL $discount", 240f, 218f, badgeText)
        }

        // Title
        val titlePaint = Paint().apply {
            color = Color.WHITE
            textSize = 58f
            isFakeBoldText = true
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(title, width / 2f, height * 0.45f, titlePaint)

        // Subtitle
        val subPaint = Paint().apply {
            color = Color.parseColor("#94A3B8")
            textSize = 34f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(subtitle, width / 2f, height * 0.54f, subPaint)

        // Price Callout
        if (price.isNotBlank()) {
            val priceBg = Paint().apply {
                color = Color.parseColor("#1E293B")
                isAntiAlias = true
            }
            canvas.drawRoundRect(width * 0.2f, height * 0.65f, width * 0.8f, height * 0.77f, 32f, 32f, priceBg)

            val pricePaint = Paint().apply {
                color = Color.parseColor("#22D3EE")
                textSize = 54f
                isFakeBoldText = true
                isAntiAlias = true
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("ONLY $price", width / 2f, height * 0.73f, pricePaint)
        }

        // Footer Contact
        val footerPaint = Paint().apply {
            color = Color.parseColor("#F8FAFC")
            textSize = 32f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        val footerText = if (phone.isNotBlank()) "Order on WhatsApp: $phone" else "Powered by FUTIVEXA AI"
        canvas.drawText(footerText, width / 2f, height - 60f, footerPaint)

        return bitmap
    }

    fun saveBitmapToCache(context: Context, bitmap: Bitmap, fileName: String = "futivexa_design.png"): Uri? {
        return try {
            val cachePath = File(context.cacheDir, "images")
            cachePath.mkdirs()
            val file = File(cachePath, fileName)
            val stream = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
            stream.close()
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        } catch (_: Exception) {
            null
        }
    }
}
