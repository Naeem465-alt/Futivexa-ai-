package com.example.core.network

import android.content.Context
import com.example.core.config.AppConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

sealed class AiResult<out T> {
    data class Success<out T>(val data: T, val isLiveAi: Boolean = true) : AiResult<T>()
    data class Error(val message: String, val urduMessage: String) : AiResult<Nothing>()
}

class GeminiService(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun generateContent(prompt: String, systemInstruction: String? = null): AiResult<String> = withContext(Dispatchers.IO) {
        val apiKey = AppConfig.getApiKey(context)

        if (apiKey.isBlank()) {
            // Intelligent fallback for offline / demo mode
            val fallback = getDomainFallback(prompt)
            return@withContext AiResult.Success(fallback, isLiveAi = false)
        }

        try {
            val root = JSONObject()
            val contents = JSONArray()
            val contentObj = JSONObject()
            val parts = JSONArray()
            val textPart = JSONObject()
            textPart.put("text", prompt)
            parts.put(textPart)
            contentObj.put("parts", parts)
            contents.put(contentObj)
            root.put("contents", contents)

            if (!systemInstruction.isNullOrBlank()) {
                val sysObj = JSONObject()
                val sysParts = JSONArray()
                val sysPart = JSONObject()
                sysPart.put("text", systemInstruction)
                sysParts.put(sysPart)
                sysObj.put("parts", sysParts)
                root.put("systemInstruction", sysObj)
            }

            // Temperature and config
            val config = JSONObject()
            config.put("temperature", 0.7)
            config.put("topP", 0.9)
            root.put("generationConfig", config)

            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
            val body = root.toString().toRequestBody(jsonMediaType)
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                if (response.code == 429) {
                    return@withContext AiResult.Error(
                        "API Rate limit reached. Using smart cached templates.",
                        "اے پی آئی ریٹ لمٹ ختم ہو گئی ہے۔ پہلے سے تیار کردہ ڈیزائن استعمال کیے جا رہے ہیں۔"
                    )
                } else if (response.code == 400 || response.code == 403) {
                    return@withContext AiResult.Error(
                        "API Key error: ${response.message}. Check Developer Configuration in Settings.",
                        "اے پی آئی کی غلط ہے۔ برائے مہربانی سیٹنگز میں چیک کریں۔"
                    )
                }
                // Fallback to domain result on network issue
                val fallback = getDomainFallback(prompt)
                return@withContext AiResult.Success(fallback, isLiveAi = false)
            }

            val jsonResponse = JSONObject(responseBody)
            val candidates = jsonResponse.optJSONArray("candidates")
            val candidate = candidates?.optJSONObject(0)
            val content = candidate?.optJSONObject("content")
            val respParts = content?.optJSONArray("parts")
            val generatedText = respParts?.optJSONObject(0)?.optString("text")

            if (!generatedText.isNullOrBlank()) {
                AiResult.Success(generatedText.trim(), isLiveAi = true)
            } else {
                val fallback = getDomainFallback(prompt)
                AiResult.Success(fallback, isLiveAi = false)
            }
        } catch (e: IOException) {
            val fallback = getDomainFallback(prompt)
            AiResult.Success(fallback, isLiveAi = false)
        } catch (e: Exception) {
            AiResult.Error(
                "Generation error: ${e.localizedMessage ?: "Unknown error"}",
                "تخلیق میں خرابی: برائے مہربانی دوبارہ کوشش کریں۔"
            )
        }
    }

    private fun getDomainFallback(prompt: String): String {
        val lower = prompt.lowercase()
        return when {
            lower.contains("urdu") || lower.contains("شاعری") || lower.contains("quotes") -> {
                """✨ زندگی کا اصل سفر وہ ہے جو انسان اپنی خود شناسی سے شروع کرتا ہے اور کامیابی کی بلندیوں تک پہنچتا ہے۔
کبھی ہمت نہ ہاریں، کیوں کہ ہر اندھیری رات کے بعد ایک روشن صبح ضرور طلوع ہوتی ہے۔
#اقوال #حوصلہ #کامیابی #فٹویوکسا"""
            }
            lower.contains("business") || lower.contains("ad") || lower.contains("product") -> {
                """🔥 EXCLUSIVE LIMITED TIME OFFER! 🔥
Elevate your style with our premium collection today!
🏷️ Flat Discount Applied | ⚡ Premium Quality Guaranteed | 🚚 Fast Island-wide Delivery
📞 Order Now on WhatsApp to claim your special discount!
#Sale #SpecialOffer #BestDeal #BusinessGrowth"""
            }
            lower.contains("whatsapp") -> {
                """🌟 Special Announcement for Our Valued Customers!
New premium stock has just arrived. Enjoy special introductory prices today only!
💬 Reply to this status to reserve yours now!"""
            }
            lower.contains("assistant") || lower.contains("marketing") -> {
                """💡 Marketing Strategy & Growth Idea:
1. Run a 'First 20 Customers' Flash Deal with 15% discount.
2. Create high-energy 9:16 WhatsApp stories showing behind-the-scenes packaging.
3. Bundle complimentary items to increase your average order value (AOV) by 25%."""
            }
            else -> {
                """🚀 FUTIVEXA AI Generated Content:
Boost your brand presence with clean, compelling headlines, strategic pricing, and targeted customer calls-to-action."""
            }
        }
    }
}
