package com.example

import android.content.Context
import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.example.core.network.GeminiService
import com.example.core.storage.AppDatabase
import com.example.core.storage.CreditManager
import com.example.core.storage.ProjectRepository
import com.example.features.assistant.AiBusinessAssistantScreen
import com.example.features.business.BusinessEditorScreen
import com.example.features.home.HomeScreen
import com.example.features.onboarding.OnboardingScreen
import com.example.features.projects.ProjectsScreen
import com.example.features.settings.SettingsScreen
import com.example.features.urdu.UrduContentCreatorScreen
import com.example.features.video.AiVideoMakerScreen
import com.example.features.whatsapp.WhatsAppCreatorScreen
import com.example.ui.theme.FutivexaCyan
import com.example.ui.theme.FutivexaTheme
import com.example.ui.theme.FutivexaViolet

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Home : Screen("home", "Home", Icons.Default.Home)
    object CreateHub : Screen("business_editor", "Create", Icons.Default.AddCircle)
    object Projects : Screen("projects", "Projects", Icons.Default.Folder)
    object Assistant : Screen("business_assistant", "Assistant", Icons.Default.Calculate)
    object Settings : Screen("settings", "Settings", Icons.Default.Settings)

    // Sub modules
    object WhatsApp : Screen("whatsapp_creator", "WhatsApp", Icons.Default.Chat)
    object Video : Screen("video_maker", "Video", Icons.Default.MovieCreation)
    object Urdu : Screen("urdu_creator", "Urdu", Icons.Default.Translate)
    object Onboarding : Screen("onboarding", "Onboarding", Icons.Default.AutoAwesome)
}

@Composable
fun MainApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("futivexa_main_prefs", Context.MODE_PRIVATE) }
    var isDarkTheme by remember { mutableStateOf(prefs.getBoolean("pref_dark_theme", true)) }
    var currentLanguage by remember { mutableStateOf(prefs.getString("pref_language", "English") ?: "English") }

    val database = remember { AppDatabase.getInstance(context) }
    val projectRepository = remember { ProjectRepository(database.projectDao()) }
    val creditManager = remember { CreditManager(context) }
    val geminiService = remember { GeminiService(context) }

    val hasOnboarded = remember { prefs.getBoolean("has_completed_onboarding", false) }
    val startDestination = if (hasOnboarded) Screen.Home.route else Screen.Onboarding.route

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val bottomBarRoutes = listOf(
        Screen.Home.route,
        Screen.Projects.route,
        Screen.Assistant.route,
        Screen.Settings.route
    )

    val showBottomBar = currentRoute in bottomBarRoutes

    val recentProjects by projectRepository.allProjects.collectAsState(initial = emptyList())

    FutivexaTheme(darkTheme = isDarkTheme) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            bottomBar = {
                if (showBottomBar) {
                    NavigationBar(
                        modifier = Modifier.testTag("main_bottom_nav"),
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 8.dp
                    ) {
                        // Home
                        NavigationBarItem(
                            selected = currentRoute == Screen.Home.route,
                            onClick = {
                                navController.navigate(Screen.Home.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                            label = { Text("Home") },
                            modifier = Modifier.testTag("nav_item_home")
                        )

                        // Create (Prominent Action)
                        NavigationBarItem(
                            selected = currentRoute == Screen.CreateHub.route,
                            onClick = {
                                navController.navigate(Screen.CreateHub.route)
                            },
                            icon = {
                                Icon(
                                    Icons.Default.AddCircle,
                                    contentDescription = "Create",
                                    tint = FutivexaViolet,
                                    modifier = Modifier.size(28.dp)
                                )
                            },
                            label = { Text("Create", color = FutivexaViolet, fontWeight = FontWeight.Bold) },
                            modifier = Modifier.testTag("nav_item_create")
                        )

                        // Projects
                        NavigationBarItem(
                            selected = currentRoute == Screen.Projects.route,
                            onClick = {
                                navController.navigate(Screen.Projects.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(Icons.Default.Folder, contentDescription = "Projects") },
                            label = { Text("Projects") },
                            modifier = Modifier.testTag("nav_item_projects")
                        )

                        // Assistant
                        NavigationBarItem(
                            selected = currentRoute == Screen.Assistant.route,
                            onClick = {
                                navController.navigate(Screen.Assistant.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(Icons.Default.Calculate, contentDescription = "Assistant") },
                            label = { Text("Assistant") },
                            modifier = Modifier.testTag("nav_item_assistant")
                        )

                        // Settings
                        NavigationBarItem(
                            selected = currentRoute == Screen.Settings.route,
                            onClick = {
                                navController.navigate(Screen.Settings.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                            label = { Text("Settings") },
                            modifier = Modifier.testTag("nav_item_settings")
                        )
                    }
                }
            }
        ) { innerPadding ->
            NavHost(
                navController = navController,
                startDestination = startDestination,
                modifier = Modifier.padding(innerPadding)
            ) {
                // Onboarding Screen
                composable(Screen.Onboarding.route) {
                    OnboardingScreen(
                        onFinished = {
                            prefs.edit().putBoolean("has_completed_onboarding", true).apply()
                            navController.navigate(Screen.Home.route) {
                                popUpTo(Screen.Onboarding.route) { inclusive = true }
                            }
                        }
                    )
                }

                // Main Home Dashboard
                composable(Screen.Home.route) {
                    HomeScreen(
                        creditManager = creditManager,
                        recentProjects = recentProjects,
                        onNavigateToModule = { moduleId ->
                            when (moduleId) {
                                "business_editor" -> navController.navigate(Screen.CreateHub.route)
                                "whatsapp_creator" -> navController.navigate(Screen.WhatsApp.route)
                                "video_maker" -> navController.navigate(Screen.Video.route)
                                "urdu_creator" -> navController.navigate(Screen.Urdu.route)
                                "business_assistant" -> navController.navigate(Screen.Assistant.route)
                            }
                        },
                        onNavigateToProject = {
                            navController.navigate(Screen.Projects.route)
                        },
                        onNavigateToSettings = {
                            navController.navigate(Screen.Settings.route)
                        }
                    )
                }

                // 1. Business Editor
                composable(Screen.CreateHub.route) {
                    BusinessEditorScreen(
                        geminiService = geminiService,
                        creditManager = creditManager,
                        projectRepository = projectRepository,
                        onNavigateBack = { navController.popBackStack() }
                    )
                }

                // 2. WhatsApp Creator
                composable(Screen.WhatsApp.route) {
                    WhatsAppCreatorScreen(
                        geminiService = geminiService,
                        creditManager = creditManager,
                        projectRepository = projectRepository,
                        onNavigateBack = { navController.popBackStack() }
                    )
                }

                // 3. AI Video Maker
                composable(Screen.Video.route) {
                    AiVideoMakerScreen(
                        creditManager = creditManager,
                        projectRepository = projectRepository,
                        onNavigateBack = { navController.popBackStack() }
                    )
                }

                // 4. Urdu Content Creator
                composable(Screen.Urdu.route) {
                    UrduContentCreatorScreen(
                        geminiService = geminiService,
                        creditManager = creditManager,
                        projectRepository = projectRepository,
                        onNavigateBack = { navController.popBackStack() }
                    )
                }

                // 5. AI Business Assistant
                composable(Screen.Assistant.route) {
                    AiBusinessAssistantScreen(
                        geminiService = geminiService,
                        creditManager = creditManager,
                        projectRepository = projectRepository,
                        onNavigateBack = { navController.popBackStack() }
                    )
                }

                // Projects Screen
                composable(Screen.Projects.route) {
                    ProjectsScreen(
                        projectRepository = projectRepository,
                        creditManager = creditManager,
                        onOpenProject = { project ->
                            when (project.type) {
                                "BUSINESS_AD" -> navController.navigate(Screen.CreateHub.route)
                                "WHATSAPP_STATUS" -> navController.navigate(Screen.WhatsApp.route)
                                "VIDEO" -> navController.navigate(Screen.Video.route)
                                "URDU_POST" -> navController.navigate(Screen.Urdu.route)
                                else -> navController.navigate(Screen.Assistant.route)
                            }
                        }
                    )
                }

                // Settings Screen
                composable(Screen.Settings.route) {
                    SettingsScreen(
                        creditManager = creditManager,
                        isDarkTheme = isDarkTheme,
                        onToggleDarkTheme = {
                            isDarkTheme = it
                            prefs.edit().putBoolean("pref_dark_theme", it).apply()
                        },
                        currentLanguage = currentLanguage,
                        onChangeLanguage = {
                            currentLanguage = it
                            prefs.edit().putString("pref_language", it).apply()
                        }
                    )
                }
            }
        }
    }
}
